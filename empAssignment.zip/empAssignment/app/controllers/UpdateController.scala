package controllers

import play.api.libs.json.{JsValue, Json}
import play.api.mvc.{Action, AnyContent, Controller, Request}
import service.UpdateService
import views.templating.JadeRenderer

/**
  * Created by rrn3194 on 5/4/16.
  */
class UpdateController(renderer: JadeRenderer) extends Controller{

  def update() = Action {
    (request: Request[AnyContent]) => {
      val jsonData = request.body.asJson.get
      val up = new UpdateService(jsonData)
      up.updateRecord
      //    Ok(renderer.render("/layout/searchResult", "searchResult" -> searchResult))
      Ok(jsonData)
    }
  }
}

object UpdateController extends UpdateController(JadeRenderer("/layout/null.jade"))